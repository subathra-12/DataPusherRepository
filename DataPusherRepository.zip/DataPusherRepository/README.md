# Backend scaffold — TypeScript + Express + TypeORM + MySQL

## Features
- TypeORM (DataSource) with MySQL
- Express with routing, controllers, services
- Auth (JWT) with middleware
- Centralized error handling middleware
- Entities, DTO validation using class-validator

## Setup
1. Copy `.env.example` to `.env` and set credentials.
2. `npm install`
3. `npm run start` (development)
4. Build with `npm run build` and run `npm run start:prod`

This scaffold is a starting point. Adjust to your needs.
